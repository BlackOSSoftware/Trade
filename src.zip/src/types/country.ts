export type Country = {
  name: string;
  dialCode: string;
  flag: string;
};
